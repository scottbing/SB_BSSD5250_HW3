package com.example.sb_bssd5250_hw3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
//import android.view.ViewManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.graphics.Color;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {

    private LinearLayout  linearLayout, linearLayout1, linearLayout2;
    private ImageButton greenButton, redButton;
    // got Java stack implementation from JournalDev article
    // https://www.journaldev.com/13401/java-stack
    private Stack<ImageButton> gbStack;
    private char green = 'g';
    private char red = 'r';

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        gbStack = new Stack<>(); // establish the green button stack

        linearLayout = new LinearLayout( this);
        // The app’s background color should be BLUE.
        linearLayout.setBackgroundColor(Color.BLUE);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams llParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
                1.0f);

        // LinearLayout #1
        linearLayout1 = new LinearLayout(this);
        // The top linearLayout should have a BLACK background.
        linearLayout1.setBackgroundColor(Color.BLACK);
        linearLayout1.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams llParams1 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
                1.0f);

        // LinearLayout #2
        linearLayout2 = new LinearLayout(this);
        // The bottom LinearLayout should have a GRAY background.
        linearLayout2.setBackgroundColor(Color.GRAY);
        linearLayout2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams llParams2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
                1.0f);

        linearLayout1.setLayoutParams(llParams1);
        linearLayout2.setLayoutParams(llParams2);

        // add buttons to layout
        // The top linearLayout will have one green button, the bottom linearlayout will have no red buttons.
        linearLayout1.addView(CreateImageButton(green));
        // linearLayout2.addView(CreateImageButton(red));  // //Only a green  button appears at start

        // add the children layouts to parent layout
        linearLayout.addView(linearLayout1);
        linearLayout.addView(linearLayout2);

        // add the parent layout
        setContentView(linearLayout, llParams);
    }

    // When a green button is pressed, a new red button will be added  to the
    // bottom linear layout and a new green button added to the top linear layout.
    private View.OnClickListener gbClickedListener = new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            // When a green button is pressed, a new red button will be added to the bottom
            // linear layout and a new green button added to the top linear layout.
            //((ViewManager)view.getParent()).removeView(view);
            linearLayout2.addView(CreateImageButton(red));
            linearLayout1.addView(CreateImageButton(green));

        }
    };

    // When a red button is pressed, a green button will be removed from the top linearlayout.
    private View.OnClickListener rbClickedListener = new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            // got Java stack implementation from JournalDev article
            // https://www.journaldev.com/13401/java-stack
            // When a red button is pressed, a green button will be removed from the top linearlayout.

            // pop from non-empty stack
            if (!gbStack.isEmpty()) {
                linearLayout1.removeView(gbStack.pop());
            }


        }
    };

    // ImageButton Factory Method
    private ImageButton CreateImageButton(char color) {
        ImageButton imgButton;
        imgButton = new ImageButton(this);
        imgButton.setBackground(null);
        if (color == 'g') {
            imgButton.setImageResource(R.drawable.green);
            imgButton.setOnClickListener(gbClickedListener);
        }
        if (color == 'r') {
            imgButton.setImageResource(R.drawable.red);
            imgButton.setOnClickListener(rbClickedListener);
        }
        imgButton.setLayoutParams( new LinearLayout.LayoutParams(
                75, 75));
        // push it on the stack
        gbStack.push((ImageButton)imgButton);
        return imgButton;
    }
}

